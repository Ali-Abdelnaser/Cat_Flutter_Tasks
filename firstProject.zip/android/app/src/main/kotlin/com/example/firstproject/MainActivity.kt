package com.example.firstproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

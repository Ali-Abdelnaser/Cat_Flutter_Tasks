import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Information",
            textAlign: TextAlign.start,
            style: TextStyle(
              color: Colors.white,
            )),
        backgroundColor: Colors.blue,
      ),
      drawer: Drawer(
        backgroundColor: Colors.black,
      ),
      body: Column(children: [
        Container(
          margin: EdgeInsets.only(top: 20, bottom: 20),
          width: 250,
          height: 250,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(120),
            border: Border.all(color: Colors.blue, width: 3),
            image: DecorationImage(
              image: AssetImage("assets/profile_picture.jpg"),
              fit: BoxFit.cover,
            ),
          ),
        ),
        Text(
          "Hello, ",
          style: TextStyle(
              color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            children: [
              Text(
                "My Name is ",
                style: TextStyle(
                    color: Color(0xff000000),
                    fontSize: 20,
                    fontWeight: FontWeight.w400),
              ),
              Text(
                "Ali Abdelnaser Ibrahim",
                style: TextStyle(
                    color: Colors.blue,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 2),
          child: Text(
            " I am 20 years old and currently studying in the Faculty of Engineering, first year, Communications Department.",
            style: TextStyle(
                color: Color(0xff000000),
                fontSize: 20,
                fontWeight: FontWeight.w400),
          ),
        ),
        Text(
          "My address is : ",
          style: TextStyle(
              color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Text(
          "El-Beho Fereik, Aga, Dakahlia",
          style: TextStyle(
              color: Color(0xff000000),
              fontSize: 20,
              fontWeight: FontWeight.w400),
        ),
        Text(
          "My Phone Number is : ",
          style: TextStyle(
              color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Text(
          "+201068643407",
          style: TextStyle(
              color: Color(0xff000000),
              fontSize: 20,
              fontWeight: FontWeight.w400),
        ),
      ]),
    );
  }
}

// Container(
//   decoration: BoxDecoration(
//     color: Colors.blue,
//     border: Border.all(color: Color(0xff2b2b2b), width: 3),
//     borderRadius: BorderRadius.circular(25),
//   ),
//   margin: EdgeInsets.only(top: 10),
//   padding: EdgeInsets.all(5),
//   child: Text(" Ali Abdelnaser ",
//       style: TextStyle(
//           fontSize: 35,
//           fontWeight: FontWeight.bold,
//           letterSpacing: 1,
//           color: Color(0xffffffff),
//           shadows: [
//             Shadow(
//               color: Colors.black,
//               blurRadius: 10,
//               offset: Offset(3, 5),
//             )
//           ])),
// ),
